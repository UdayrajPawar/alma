const mongoose = require('mongoose');

const NotificationSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', index: true, required: true },
  type: { 
    type: String, 
    enum: [
      'connection_request',
      'connection_accepted',
      'message',
      'post_like',
      'post_comment',
      'event_invite',
      'event_reminder',
      'job_apply',
      'institute_verified',
      'admin_action'
    ],
    required: true
  },
  payload: { type: mongoose.Schema.Types.Mixed },
  read: { type: Boolean, default: false },
  link: { type: String }
}, {
  timestamps: true
});

NotificationSchema.index({ userId: 1, read: 1, createdAt: -1 });
NotificationSchema.index({ createdAt: 1 }, { expireAfterSeconds: 90 * 24 * 60 * 60 });

module.exports = mongoose.model('Notification', NotificationSchema);

