const User = require('./User');
const Institute = require('./Institute');
const Post = require('./Post');
const Comment = require('./Comment');
const Event = require('./Event');
const Job = require('./Job');
const Conversation = require('./Conversation');
const Message = require('./Message');
const Notification = require('./Notification');

module.exports = {
  User,
  Institute,
  Post,
  Comment,
  Event,
  Job,
  Conversation,
  Message,
  Notification
};

