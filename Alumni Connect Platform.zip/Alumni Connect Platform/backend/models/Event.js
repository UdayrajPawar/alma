const mongoose = require('mongoose');

const EventSchema = new mongoose.Schema({
  title: { type: String, required: true, index: true },
  description: { type: String },
  hostUserId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  hostInstituteId: { type: mongoose.Schema.Types.ObjectId, ref: 'Institute' },
  location: { type: String },
  startAt: { type: Date, required: true, index: true },
  endAt: { type: Date },
  capacity: { type: Number },
  attendees: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  imageUrl: { type: String },
  deleted: { type: Boolean, default: false },
  deletedAt: { type: Date }
}, {
  timestamps: true
});

EventSchema.index({ startAt: 1 });
EventSchema.index({ hostInstituteId: 1 });

module.exports = mongoose.model('Event', EventSchema);

