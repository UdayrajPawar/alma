const mongoose = require('mongoose');

const PostSchema = new mongoose.Schema({
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  content: { type: String },
  mediaUrls: [{ type: String }],
  tags: [{ type: String, index: true }],
  likes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  commentsCount: { type: Number, default: 0 },
  instituteId: { type: mongoose.Schema.Types.ObjectId, ref: 'Institute' },
  deleted: { type: Boolean, default: false },
  deletedAt: { type: Date }
}, {
  timestamps: true
});

PostSchema.index({ author: 1, createdAt: -1 });
PostSchema.index({ instituteId: 1, createdAt: -1 });
PostSchema.index({ content: 'text' });

module.exports = mongoose.model('Post', PostSchema);

