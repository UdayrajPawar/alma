const mongoose = require('mongoose');

const InstituteSchema = new mongoose.Schema({
  name: { type: String, required: true, index: true },
  alias: { type: String },
  description: { type: String },
  location: {
    city: String,
    state: String,
    country: String
  },
  website: { type: String },
  logoUrl: { type: String },
  verified: { type: Boolean, default: false },
  admins: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  deleted: { type: Boolean, default: false },
  deletedAt: { type: Date }
}, {
  timestamps: true
});

InstituteSchema.index({ name: 'text', description: 'text' });

module.exports = mongoose.model('Institute', InstituteSchema);

