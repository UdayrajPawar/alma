const mongoose = require('mongoose');

const JobSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  company: { type: String },
  postedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  instituteId: { type: mongoose.Schema.Types.ObjectId, ref: 'Institute' },
  location: { type: String },
  type: { type: String, enum: ['Full-time', 'Part-time', 'Internship', 'Contract'] },
  applyUrl: { type: String },
  applicants: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    appliedAt: { type: Date, default: Date.now },
    resumeUrl: { type: String }
  }],
  expireAt: { type: Date },
  deleted: { type: Boolean, default: false },
  deletedAt: { type: Date }
}, {
  timestamps: true
});

JobSchema.index({ postedBy: 1, createdAt: -1 });
JobSchema.index({ instituteId: 1 });
JobSchema.index({ expireAt: 1 }, { expireAfterSeconds: 0 });

module.exports = mongoose.model('Job', JobSchema);

