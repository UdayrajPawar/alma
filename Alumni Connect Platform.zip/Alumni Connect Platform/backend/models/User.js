const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const SocialSchema = new mongoose.Schema({
  linkedin: { type: String },
  github: { type: String },
  twitter: { type: String },
  website: { type: String },
}, { _id: false });

const EducationSchema = new mongoose.Schema({
  instituteId: { type: mongoose.Schema.Types.ObjectId, ref: 'Institute' },
  instituteName: { type: String },
  degree: { type: String },
  branch: { type: String },
  startYear: { type: Number },
  endYear: { type: Number },
}, { _id: false });

const UserSchema = new mongoose.Schema({
  firstName: { type: String, required: true, trim: true, index: true },
  lastName: { type: String, trim: true, index: true },
  fullName: { type: String, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, index: true },
  passwordHash: { type: String },
  avatarUrl: { type: String },
  headline: { type: String },
  bio: { type: String },
  currentCompany: { type: String },
  currentPosition: { type: String },
  skills: [{ type: String, index: true }],
  education: [EducationSchema],
  batch: { type: Number, index: true },
  isAlumnus: { type: Boolean, default: false },
  instituteIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Institute', index: true }],
  connections: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  pendingConnections: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    createdAt: { type: Date, default: Date.now }
  }],
  receivedConnections: [{
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    createdAt: { type: Date, default: Date.now }
  }],
  roles: [{ type: String, enum: ['user', 'institute_admin', 'platform_admin'], default: 'user' }],
  verifiedInstitutes: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Institute' }],
  resumeUrl: { type: String },
  social: SocialSchema,
  oauthProviders: [{ provider: String, providerId: String }],
  lastSeenAt: { type: Date },
  deleted: { type: Boolean, default: false },
  deletedAt: { type: Date }
}, {
  timestamps: true
});

UserSchema.index({ fullName: 'text', bio: 'text', skills: 'text' });
UserSchema.index({ email: 1 });
UserSchema.index({ instituteIds: 1 });
UserSchema.index({ batch: 1 });

UserSchema.pre('save', function(next) {
  if (this.isModified('firstName') || this.isModified('lastName')) {
    this.fullName = `${this.firstName} ${this.lastName || ''}`.trim();
  }
  next();
});

UserSchema.methods.comparePassword = async function(candidatePassword) {
  if (!this.passwordHash) return false;
  return bcrypt.compare(candidatePassword, this.passwordHash);
};

module.exports = mongoose.model('User', UserSchema);

