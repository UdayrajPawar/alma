const { Event, User, Notification } = require('../models');
const { uploadToS3 } = require('../utils/s3');

const createEvent = async (req, res, next) => {
  try {
    const { title, description, location, startAt, endAt, capacity, hostInstituteId } = req.body;
    
    let imageUrl;
    if (req.file) {
      imageUrl = await uploadToS3(req.file, 'events');
    }

    const event = await Event.create({
      title,
      description,
      location,
      startAt,
      endAt,
      capacity,
      hostUserId: req.user._id,
      hostInstituteId,
      imageUrl
    });

    await event.populate('hostUserId', 'firstName lastName avatarUrl');
    if (hostInstituteId) {
      await event.populate('hostInstituteId', 'name logoUrl');
    }

    res.status(201).json(event);
  } catch (error) {
    next(error);
  }
};

const getEvents = async (req, res, next) => {
  try {
    const { instituteId, upcoming = true, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;
    const query = { deleted: false };

    if (instituteId) {
      query.hostInstituteId = instituteId;
    }

    if (upcoming === 'true') {
      query.startAt = { $gte: new Date() };
    }

    const events = await Event.find(query)
      .populate('hostUserId', 'firstName lastName avatarUrl')
      .populate('hostInstituteId', 'name logoUrl')
      .sort({ startAt: 1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Event.countDocuments(query);

    res.json({ events, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    next(error);
  }
};

const getEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id)
      .populate('hostUserId', 'firstName lastName avatarUrl')
      .populate('hostInstituteId', 'name logoUrl')
      .populate('attendees', 'firstName lastName avatarUrl');

    if (!event || event.deleted) {
      return res.status(404).json({ error: 'Event not found' });
    }

    res.json(event);
  } catch (error) {
    next(error);
  }
};

const rsvpEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id);
    
    if (!event || event.deleted) {
      return res.status(404).json({ error: 'Event not found' });
    }

    if (event.capacity && event.attendees.length >= event.capacity) {
      return res.status(400).json({ error: 'Event is full' });
    }

    const isAttending = event.attendees.includes(req.user._id);
    
    if (isAttending) {
      event.attendees = event.attendees.filter(id => id.toString() !== req.user._id.toString());
    } else {
      event.attendees.push(req.user._id);
      
      await Notification.create({
        userId: event.hostUserId,
        type: 'event_invite',
        payload: { eventId: event._id, eventTitle: event.title, fromUserId: req.user._id }
      });
    }

    await event.save();
    res.json({ attending: !isAttending, attendeesCount: event.attendees.length });
  } catch (error) {
    next(error);
  }
};

const deleteEvent = async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.id);
    
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }

    if (event.hostUserId.toString() !== req.user._id.toString() && !req.user.roles.includes('platform_admin')) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    event.deleted = true;
    event.deletedAt = new Date();
    await event.save();

    res.json({ message: 'Event deleted' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createEvent,
  getEvents,
  getEvent,
  rsvpEvent,
  deleteEvent
};

