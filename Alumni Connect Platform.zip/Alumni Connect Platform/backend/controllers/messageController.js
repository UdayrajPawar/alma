const { Conversation, Message, User, Notification } = require('../models');
const { uploadToS3 } = require('../utils/s3');

const getConversations = async (req, res, next) => {
  try {
    const conversations = await Conversation.find({
      participants: req.user._id
    })
      .populate('participants', 'firstName lastName avatarUrl')
      .sort({ lastMessageAt: -1 });

    res.json(conversations);
  } catch (error) {
    next(error);
  }
};

const getOrCreateConversation = async (req, res, next) => {
  try {
    const { participantIds } = req.body;
    const allParticipants = [...participantIds, req.user._id.toString()].sort();

    let conversation = await Conversation.findOne({
      participants: { $all: allParticipants, $size: allParticipants.length }
    });

    if (!conversation) {
      conversation = await Conversation.create({
        participants: allParticipants
      });
    }

    await conversation.populate('participants', 'firstName lastName avatarUrl');

    res.json(conversation);
  } catch (error) {
    next(error);
  }
};

const getMessages = async (req, res, next) => {
  try {
    const { page = 1, limit = 50 } = req.query;
    const skip = (page - 1) * limit;

    const conversation = await Conversation.findById(req.params.id);
    if (!conversation || !conversation.participants.includes(req.user._id)) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const messages = await Message.find({
      conversationId: req.params.id,
      deleted: false
    })
      .populate('sender', 'firstName lastName avatarUrl')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.json(messages.reverse());
  } catch (error) {
    next(error);
  }
};

const sendMessage = async (req, res, next) => {
  try {
    const { content } = req.body;
    const conversation = await Conversation.findById(req.params.id);

    if (!conversation || !conversation.participants.includes(req.user._id)) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const attachments = [];
    if (req.files) {
      for (const file of req.files) {
        const url = await uploadToS3(file, 'messages');
        attachments.push({ url, filename: file.originalname });
      }
    }

    const message = await Message.create({
      conversationId: req.params.id,
      sender: req.user._id,
      content,
      attachments,
      readBy: [req.user._id]
    });

    conversation.lastMessageAt = new Date();
    conversation.lastMessage = content || 'Attachment';
    await conversation.save();

    await message.populate('sender', 'firstName lastName avatarUrl');

    const otherParticipants = conversation.participants.filter(
      p => p.toString() !== req.user._id.toString()
    );

    for (const participantId of otherParticipants) {
      await Notification.create({
        userId: participantId,
        type: 'message',
        payload: { conversationId: conversation._id, fromUserId: req.user._id, fromUserName: req.user.fullName }
      });
    }

    res.status(201).json(message);
  } catch (error) {
    next(error);
  }
};

const markAsRead = async (req, res, next) => {
  try {
    const conversation = await Conversation.findById(req.params.id);
    if (!conversation || !conversation.participants.includes(req.user._id)) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    await Message.updateMany(
      { conversationId: req.params.id, sender: { $ne: req.user._id } },
      { $addToSet: { readBy: req.user._id } }
    );

    res.json({ message: 'Messages marked as read' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getConversations,
  getOrCreateConversation,
  getMessages,
  sendMessage,
  markAsRead
};

