const { Job, User, Notification } = require('../models');
const { uploadToS3 } = require('../utils/s3');

const createJob = async (req, res, next) => {
  try {
    const { title, description, company, location, type, applyUrl, instituteId, expireAt } = req.body;

    const job = await Job.create({
      title,
      description,
      company,
      location,
      type,
      applyUrl,
      postedBy: req.user._id,
      instituteId,
      expireAt: expireAt ? new Date(expireAt) : null
    });

    await job.populate('postedBy', 'firstName lastName avatarUrl');
    if (instituteId) {
      await job.populate('instituteId', 'name logoUrl');
    }

    res.status(201).json(job);
  } catch (error) {
    next(error);
  }
};

const getJobs = async (req, res, next) => {
  try {
    const { instituteId, company, type, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;
    const query = { deleted: false, $or: [{ expireAt: null }, { expireAt: { $gte: new Date() } }] };

    if (instituteId) {
      query.instituteId = instituteId;
    }
    if (company) {
      query.company = new RegExp(company, 'i');
    }
    if (type) {
      query.type = type;
    }

    const jobs = await Job.find(query)
      .populate('postedBy', 'firstName lastName avatarUrl')
      .populate('instituteId', 'name logoUrl')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Job.countDocuments(query);

    res.json({ jobs, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    next(error);
  }
};

const getJob = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id)
      .populate('postedBy', 'firstName lastName avatarUrl')
      .populate('instituteId', 'name logoUrl')
      .populate('applicants.userId', 'firstName lastName avatarUrl email');

    if (!job || job.deleted) {
      return res.status(404).json({ error: 'Job not found' });
    }

    res.json(job);
  } catch (error) {
    next(error);
  }
};

const applyJob = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id);
    
    if (!job || job.deleted) {
      return res.status(404).json({ error: 'Job not found' });
    }

    if (job.expireAt && job.expireAt < new Date()) {
      return res.status(400).json({ error: 'Job has expired' });
    }

    const hasApplied = job.applicants.some(a => a.userId.toString() === req.user._id.toString());
    if (hasApplied) {
      return res.status(400).json({ error: 'Already applied' });
    }

    let resumeUrl = req.user.resumeUrl;
    if (req.file) {
      resumeUrl = await uploadToS3(req.file, 'resumes');
    }

    if (!resumeUrl) {
      return res.status(400).json({ error: 'Resume required' });
    }

    job.applicants.push({
      userId: req.user._id,
      appliedAt: new Date(),
      resumeUrl
    });

    await job.save();

    if (job.postedBy.toString() !== req.user._id.toString()) {
      await Notification.create({
        userId: job.postedBy,
        type: 'job_apply',
        payload: { jobId: job._id, jobTitle: job.title, fromUserId: req.user._id, fromUserName: req.user.fullName }
      });
    }

    res.json({ message: 'Application submitted' });
  } catch (error) {
    next(error);
  }
};

const deleteJob = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id);
    
    if (!job) {
      return res.status(404).json({ error: 'Job not found' });
    }

    if (job.postedBy.toString() !== req.user._id.toString() && !req.user.roles.includes('platform_admin')) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    job.deleted = true;
    job.deletedAt = new Date();
    await job.save();

    res.json({ message: 'Job deleted' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createJob,
  getJobs,
  getJob,
  applyJob,
  deleteJob
};

