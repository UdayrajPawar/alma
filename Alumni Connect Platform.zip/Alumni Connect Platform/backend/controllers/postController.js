const { Post, Comment, User, Notification } = require('../models');
const { uploadToS3 } = require('../utils/s3');

const createPost = async (req, res, next) => {
  try {
    const { content, tags, instituteId } = req.body;
    const mediaUrls = [];

    if (req.files) {
      for (const file of req.files) {
        const url = await uploadToS3(file, 'posts');
        mediaUrls.push(url);
      }
    }

    const post = await Post.create({
      author: req.user._id,
      content,
      tags: tags ? (Array.isArray(tags) ? tags : tags.split(',')) : [],
      mediaUrls,
      instituteId
    });

    await post.populate('author', 'firstName lastName avatarUrl');

    res.status(201).json(post);
  } catch (error) {
    next(error);
  }
};

const getPosts = async (req, res, next) => {
  try {
    const { type = 'feed', userId, instituteId, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;
    const query = { deleted: false };

    if (type === 'user' && userId) {
      query.author = userId;
    } else if (type === 'institute' && instituteId) {
      query.instituteId = instituteId;
    } else if (type === 'feed') {
      const user = await User.findById(req.user._id);
      query.$or = [
        { author: { $in: user.connections } },
        { instituteId: { $in: user.instituteIds } },
        { author: req.user._id }
      ];
    }

    const posts = await Post.find(query)
      .populate('author', 'firstName lastName avatarUrl headline')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Post.countDocuments(query);

    res.json({ posts, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    next(error);
  }
};

const getPost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id)
      .populate('author', 'firstName lastName avatarUrl headline')
      .populate('likes', 'firstName lastName avatarUrl');

    if (!post || post.deleted) {
      return res.status(404).json({ error: 'Post not found' });
    }

    res.json(post);
  } catch (error) {
    next(error);
  }
};

const likePost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post || post.deleted) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const isLiked = post.likes.includes(req.user._id);
    
    if (isLiked) {
      post.likes = post.likes.filter(id => id.toString() !== req.user._id.toString());
    } else {
      post.likes.push(req.user._id);
      
      if (post.author.toString() !== req.user._id.toString()) {
        await Notification.create({
          userId: post.author,
          type: 'post_like',
          payload: { postId: post._id, fromUserId: req.user._id, fromUserName: req.user.fullName }
        });
      }
    }

    await post.save();
    res.json({ liked: !isLiked, likesCount: post.likes.length });
  } catch (error) {
    next(error);
  }
};

const addComment = async (req, res, next) => {
  try {
    const { content, parentCommentId } = req.body;
    const post = await Post.findById(req.params.id);

    if (!post || post.deleted) {
      return res.status(404).json({ error: 'Post not found' });
    }

    const comment = await Comment.create({
      postId: req.params.id,
      author: req.user._id,
      content,
      parentCommentId
    });

    post.commentsCount += 1;
    await post.save();

    await comment.populate('author', 'firstName lastName avatarUrl');

    if (post.author.toString() !== req.user._id.toString()) {
      await Notification.create({
        userId: post.author,
        type: 'post_comment',
        payload: { postId: post._id, commentId: comment._id, fromUserId: req.user._id, fromUserName: req.user.fullName }
      });
    }

    res.status(201).json(comment);
  } catch (error) {
    next(error);
  }
};

const getComments = async (req, res, next) => {
  try {
    const comments = await Comment.find({ postId: req.params.id, deleted: false })
      .populate('author', 'firstName lastName avatarUrl')
      .sort({ createdAt: -1 });

    res.json(comments);
  } catch (error) {
    next(error);
  }
};

const deletePost = async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    
    if (!post) {
      return res.status(404).json({ error: 'Post not found' });
    }

    if (post.author.toString() !== req.user._id.toString() && !req.user.roles.includes('platform_admin')) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    post.deleted = true;
    post.deletedAt = new Date();
    await post.save();

    res.json({ message: 'Post deleted' });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createPost,
  getPosts,
  getPost,
  likePost,
  addComment,
  getComments,
  deletePost
};

