const { User, Institute, Notification } = require('../models');
const { uploadToS3 } = require('../utils/s3');

const getProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id)
      .populate('instituteIds', 'name logoUrl verified')
      .populate('connections', 'firstName lastName avatarUrl headline')
      .select('-passwordHash');

    if (!user || user.deleted) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(user);
  } catch (error) {
    next(error);
  }
};

const updateProfile = async (req, res, next) => {
  try {
    if (req.user._id.toString() !== req.params.id) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const updates = req.body;
    if (req.file) {
      updates.avatarUrl = await uploadToS3(req.file, 'avatars');
    }

    if (updates.resume && req.files?.resume) {
      updates.resumeUrl = await uploadToS3(req.files.resume[0], 'resumes');
    }

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { $set: updates },
      { new: true, runValidators: true }
    ).select('-passwordHash');

    res.json(user);
  } catch (error) {
    next(error);
  }
};

const searchUsers = async (req, res, next) => {
  try {
    const { q, instituteId, skills, batch, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;
    const query = { deleted: false };

    if (q) {
      query.$text = { $search: q };
    }
    if (instituteId) {
      query.instituteIds = instituteId;
    }
    if (batch) {
      query.batch = parseInt(batch);
    }
    if (skills) {
      query.skills = { $in: Array.isArray(skills) ? skills : [skills] };
    }

    const users = await User.find(query)
      .select('-passwordHash')
      .skip(skip)
      .limit(parseInt(limit))
      .sort(q ? { score: { $meta: 'textScore' } } : { createdAt: -1 });

    const total = await User.countDocuments(query);

    res.json({ users, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    next(error);
  }
};

const sendConnectionRequest = async (req, res, next) => {
  try {
    const targetUserId = req.params.id;
    const userId = req.user._id;

    if (targetUserId === userId.toString()) {
      return res.status(400).json({ error: 'Cannot connect to yourself' });
    }

    const targetUser = await User.findById(targetUserId);
    if (!targetUser || targetUser.deleted) {
      return res.status(404).json({ error: 'User not found' });
    }

    const user = await User.findById(userId);

    if (user.connections.includes(targetUserId)) {
      return res.status(400).json({ error: 'Already connected' });
    }

    if (user.pendingConnections.some(c => c.userId.toString() === targetUserId)) {
      return res.status(400).json({ error: 'Request already sent' });
    }

    user.pendingConnections.push({ userId: targetUserId });
    targetUser.receivedConnections.push({ userId });

    await user.save();
    await targetUser.save();

    await Notification.create({
      userId: targetUserId,
      type: 'connection_request',
      payload: { fromUserId: userId, fromUserName: user.fullName }
    });

    res.json({ message: 'Connection request sent' });
  } catch (error) {
    next(error);
  }
};

const acceptConnection = async (req, res, next) => {
  try {
    const targetUserId = req.params.id;
    const userId = req.user._id;

    const user = await User.findById(userId);
    const targetUser = await User.findById(targetUserId);

    if (!user.receivedConnections.some(c => c.userId.toString() === targetUserId)) {
      return res.status(400).json({ error: 'No pending request' });
    }

    user.connections.push(targetUserId);
    targetUser.connections.push(userId);

    user.receivedConnections = user.receivedConnections.filter(
      c => c.userId.toString() !== targetUserId
    );
    targetUser.pendingConnections = targetUser.pendingConnections.filter(
      c => c.userId.toString() !== userId.toString()
    );

    await user.save();
    await targetUser.save();

    await Notification.create({
      userId: targetUserId,
      type: 'connection_accepted',
      payload: { fromUserId: userId, fromUserName: user.fullName }
    });

    res.json({ message: 'Connection accepted' });
  } catch (error) {
    next(error);
  }
};

const removeConnection = async (req, res, next) => {
  try {
    const targetUserId = req.params.id;
    const userId = req.user._id;

    await User.findByIdAndUpdate(userId, {
      $pull: { connections: targetUserId }
    });
    await User.findByIdAndUpdate(targetUserId, {
      $pull: { connections: userId }
    });

    res.json({ message: 'Connection removed' });
  } catch (error) {
    next(error);
  }
};

const getConnections = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id)
      .populate('connections', 'firstName lastName avatarUrl headline currentCompany')
      .select('connections');

    res.json(user.connections || []);
  } catch (error) {
    next(error);
  }
};

const getConnectionRequests = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id)
      .populate('receivedConnections.userId', 'firstName lastName avatarUrl headline')
      .select('receivedConnections');

    res.json(user.receivedConnections || []);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getProfile,
  updateProfile,
  searchUsers,
  sendConnectionRequest,
  acceptConnection,
  removeConnection,
  getConnections,
  getConnectionRequests
};

