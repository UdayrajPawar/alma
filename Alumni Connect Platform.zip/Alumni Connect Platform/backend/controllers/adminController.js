const { User, Institute, Post, Job, Event } = require('../models');

const getUsers = async (req, res, next) => {
  try {
    const { q, role, instituteId, page = 1, limit = 50 } = req.query;
    const skip = (page - 1) * limit;
    const query = { deleted: false };

    if (q) {
      query.$text = { $search: q };
    }
    if (role) {
      query.roles = role;
    }
    if (instituteId) {
      query.instituteIds = instituteId;
    }

    const users = await User.find(query)
      .select('-passwordHash')
      .skip(skip)
      .limit(parseInt(limit))
      .sort({ createdAt: -1 });

    const total = await User.countDocuments(query);

    res.json({ users, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    next(error);
  }
};

const verifyInstitute = async (req, res, next) => {
  try {
    const institute = await Institute.findById(req.params.id);
    if (!institute) {
      return res.status(404).json({ error: 'Institute not found' });
    }

    institute.verified = true;
    await institute.save();

    res.json({ message: 'Institute verified', institute });
  } catch (error) {
    next(error);
  }
};

const verifyUser = async (req, res, next) => {
  try {
    const { userId, instituteId } = req.body;
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    if (instituteId) {
      user.verifiedInstitutes.push(instituteId);
      await user.save();
    }

    res.json({ message: 'User verified', user });
  } catch (error) {
    next(error);
  }
};

const deleteUser = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    user.deleted = true;
    user.deletedAt = new Date();
    await user.save();

    res.json({ message: 'User deleted' });
  } catch (error) {
    next(error);
  }
};

const getStats = async (req, res, next) => {
  try {
    const totalUsers = await User.countDocuments({ deleted: false });
    const totalInstitutes = await Institute.countDocuments({ deleted: false });
    const totalPosts = await Post.countDocuments({ deleted: false });
    const totalJobs = await Job.countDocuments({ deleted: false });
    const totalEvents = await Event.countDocuments({ deleted: false });

    res.json({
      totalUsers,
      totalInstitutes,
      totalPosts,
      totalJobs,
      totalEvents
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getUsers,
  verifyInstitute,
  verifyUser,
  deleteUser,
  getStats
};

