const { Institute, User } = require('../models');
const { uploadToS3 } = require('../utils/s3');

const createInstitute = async (req, res, next) => {
  try {
    const { name, alias, description, location, website } = req.body;
    
    let logoUrl;
    if (req.file) {
      logoUrl = await uploadToS3(req.file, 'institutes');
    }

    const institute = await Institute.create({
      name,
      alias,
      description,
      location,
      website,
      logoUrl,
      admins: [req.user._id]
    });

    await User.findByIdAndUpdate(req.user._id, {
      $addToSet: { roles: 'institute_admin' }
    });

    res.status(201).json(institute);
  } catch (error) {
    next(error);
  }
};

const getInstitutes = async (req, res, next) => {
  try {
    const { q, verified, page = 1, limit = 20 } = req.query;
    const skip = (page - 1) * limit;
    const query = { deleted: false };

    if (q) {
      query.$text = { $search: q };
    }
    if (verified !== undefined) {
      query.verified = verified === 'true';
    }

    const institutes = await Institute.find(query)
      .sort(q ? { score: { $meta: 'textScore' } } : { createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    const total = await Institute.countDocuments(query);

    res.json({ institutes, total, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    next(error);
  }
};

const getInstitute = async (req, res, next) => {
  try {
    const institute = await Institute.findById(req.params.id)
      .populate('admins', 'firstName lastName avatarUrl');

    if (!institute || institute.deleted) {
      return res.status(404).json({ error: 'Institute not found' });
    }

    res.json(institute);
  } catch (error) {
    next(error);
  }
};

const updateInstitute = async (req, res, next) => {
  try {
    const institute = await Institute.findById(req.params.id);
    
    if (!institute) {
      return res.status(404).json({ error: 'Institute not found' });
    }

    if (!institute.admins.includes(req.user._id) && !req.user.roles.includes('platform_admin')) {
      return res.status(403).json({ error: 'Unauthorized' });
    }

    const updates = req.body;
    if (req.file) {
      updates.logoUrl = await uploadToS3(req.file, 'institutes');
    }

    const updated = await Institute.findByIdAndUpdate(
      req.params.id,
      { $set: updates },
      { new: true, runValidators: true }
    );

    res.json(updated);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createInstitute,
  getInstitutes,
  getInstitute,
  updateInstitute
};

