const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { authenticate, authorize } = require('../middleware/auth');

router.use(authenticate);
router.use(authorize('platform_admin'));

router.get('/users', adminController.getUsers);
router.get('/stats', adminController.getStats);
router.post('/institutes/:id/verify', adminController.verifyInstitute);
router.post('/users/verify', adminController.verifyUser);
router.delete('/users/:id', adminController.deleteUser);

module.exports = router;

