const express = require('express');
const router = express.Router();
const jobController = require('../controllers/jobController');
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', jobController.getJobs);
router.get('/:id', authenticate, jobController.getJob);

router.post('/', authenticate, jobController.createJob);
router.post('/:id/apply', authenticate, upload.single('resume'), jobController.applyJob);

router.delete('/:id', authenticate, jobController.deleteJob);

module.exports = router;

