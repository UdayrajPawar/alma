const express = require('express');
const router = express.Router();
const eventController = require('../controllers/eventController');
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', eventController.getEvents);
router.get('/:id', authenticate, eventController.getEvent);

router.post('/', authenticate, upload.single('image'), eventController.createEvent);
router.post('/:id/rsvp', authenticate, eventController.rsvpEvent);

router.delete('/:id', authenticate, eventController.deleteEvent);

module.exports = router;

