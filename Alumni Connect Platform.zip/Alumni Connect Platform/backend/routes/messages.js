const express = require('express');
const router = express.Router();
const messageController = require('../controllers/messageController');
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', authenticate, messageController.getConversations);
router.get('/:id/messages', authenticate, messageController.getMessages);

router.post('/', authenticate, messageController.getOrCreateConversation);
router.post('/:id/messages', authenticate, upload.array('attachments', 5), messageController.sendMessage);
router.post('/:id/read', authenticate, messageController.markAsRead);

module.exports = router;

