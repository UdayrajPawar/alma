const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/search', userController.searchUsers);
router.get('/:id', userController.getProfile);
router.get('/:id/connections', userController.getConnections);
router.get('/connections/requests', authenticate, userController.getConnectionRequests);

router.put('/:id', authenticate, upload.single('avatar'), userController.updateProfile);

router.post('/:id/connect', authenticate, userController.sendConnectionRequest);
router.post('/:id/connect/accept', authenticate, userController.acceptConnection);
router.delete('/:id/connect', authenticate, userController.removeConnection);

module.exports = router;

