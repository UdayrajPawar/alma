const express = require('express');
const router = express.Router();
const postController = require('../controllers/postController');
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', authenticate, postController.getPosts);
router.get('/:id', authenticate, postController.getPost);
router.get('/:id/comments', authenticate, postController.getComments);

router.post('/', authenticate, upload.array('media', 5), postController.createPost);
router.post('/:id/like', authenticate, postController.likePost);
router.post('/:id/comment', authenticate, postController.addComment);

router.delete('/:id', authenticate, postController.deletePost);

module.exports = router;

