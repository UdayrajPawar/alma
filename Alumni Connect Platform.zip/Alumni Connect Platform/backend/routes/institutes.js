const express = require('express');
const router = express.Router();
const instituteController = require('../controllers/instituteController');
const { authenticate } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', instituteController.getInstitutes);
router.get('/:id', instituteController.getInstitute);

router.post('/', authenticate, upload.single('logo'), instituteController.createInstitute);
router.put('/:id', authenticate, upload.single('logo'), instituteController.updateInstitute);

module.exports = router;

