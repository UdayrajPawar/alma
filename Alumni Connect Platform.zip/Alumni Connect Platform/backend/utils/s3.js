const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION || 'us-east-1'
});

const uploadToS3 = async (file, folder = 'uploads') => {
  const key = `${folder}/${uuidv4()}-${file.originalname}`;
  
  const params = {
    Bucket: process.env.S3_BUCKET,
    Key: key,
    Body: file.buffer,
    ContentType: file.mimetype,
    ACL: 'public-read'
  };

  const result = await s3.upload(params).promise();
  return result.Location;
};

const getPresignedUrl = (key, folder = 'uploads') => {
  const fullKey = `${folder}/${key}`;
  
  return s3.getSignedUrl('putObject', {
    Bucket: process.env.S3_BUCKET,
    Key: fullKey,
    Expires: 300,
    ContentType: 'image/jpeg'
  });
};

const deleteFromS3 = async (url) => {
  const key = url.split('.com/')[1];
  if (!key) return;

  const params = {
    Bucket: process.env.S3_BUCKET,
    Key: key
  };

  try {
    await s3.deleteObject(params).promise();
  } catch (error) {
    console.error('Error deleting from S3:', error);
  }
};

module.exports = { uploadToS3, getPresignedUrl, deleteFromS3 };

