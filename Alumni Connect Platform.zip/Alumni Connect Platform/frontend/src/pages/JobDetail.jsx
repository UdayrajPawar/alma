import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { jobAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { FiBriefcase, FiMapPin, FiClock, FiExternalLink } from 'react-icons/fi';
import { format } from 'date-fns';

const JobDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [hasApplied, setHasApplied] = useState(false);

  useEffect(() => {
    fetchJob();
  }, [id]);

  const fetchJob = async () => {
    try {
      const response = await jobAPI.getJob(id);
      setJob(response.data);
      setHasApplied(response.data.applicants?.some(a => a.userId === user?.id));
    } catch (error) {
      console.error('Error fetching job:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApply = async () => {
    setApplying(true);
    try {
      await jobAPI.applyJob(id);
      setHasApplied(true);
      alert('Application submitted successfully!');
      fetchJob();
    } catch (error) {
      console.error('Error applying:', error);
      alert('Failed to submit application');
    } finally {
      setApplying(false);
    }
  };

  if (loading) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  if (!job) {
    return <div className="container mx-auto px-4 py-8">Job not found</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-start justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">{job.title}</h1>
              <p className="text-xl text-gray-700">{job.company}</p>
            </div>
            {!hasApplied ? (
              job.applyUrl ? (
                <a
                  href={job.applyUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2"
                >
                  <span>Apply Now</span>
                  <FiExternalLink />
                </a>
              ) : (
                <button
                  onClick={handleApply}
                  disabled={applying}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                >
                  {applying ? 'Applying...' : 'Apply Now'}
                </button>
              )
            ) : (
              <button
                disabled
                className="px-6 py-2 bg-green-600 text-white rounded-lg"
              >
                Applied
              </button>
            )}
          </div>

          <div className="flex flex-wrap gap-4 mb-6 text-gray-700">
            <div className="flex items-center space-x-2">
              <FiBriefcase className="text-blue-600" />
              <span>{job.type}</span>
            </div>
            <div className="flex items-center space-x-2">
              <FiMapPin className="text-blue-600" />
              <span>{job.location}</span>
            </div>
            <div className="flex items-center space-x-2">
              <FiClock className="text-blue-600" />
              <span>Posted {format(new Date(job.createdAt), 'MMM d, yyyy')}</span>
            </div>
          </div>

          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-3">Job Description</h2>
            <p className="text-gray-700 whitespace-pre-wrap">{job.description}</p>
          </div>

          {job.postedBy && (
            <div className="border-t pt-6">
              <h2 className="text-xl font-semibold mb-4">Posted by</h2>
              <Link
                to={`/profile/${job.postedBy._id}`}
                className="flex items-center space-x-3 hover:bg-gray-50 p-2 rounded-lg"
              >
                {job.postedBy.avatarUrl ? (
                  <img
                    src={job.postedBy.avatarUrl}
                    alt={job.postedBy.fullName}
                    className="w-12 h-12 rounded-full"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white">
                    {job.postedBy.firstName?.[0]}
                  </div>
                )}
                <div>
                  <p className="font-medium">{job.postedBy.fullName}</p>
                  {job.postedBy.headline && (
                    <p className="text-sm text-gray-600">{job.postedBy.headline}</p>
                  )}
                </div>
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobDetail;
