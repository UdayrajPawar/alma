import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { instituteAPI, postAPI, eventAPI } from '../services/api';
import PostCard from '../components/PostCard';
import EventCard from '../components/EventCard';
import { FiMapPin, FiGlobe, FiCheckCircle } from 'react-icons/fi';

const InstituteDetail = () => {
  const { id } = useParams();
  const [institute, setInstitute] = useState(null);
  const [posts, setPosts] = useState([]);
  const [events, setEvents] = useState([]);
  const [activeTab, setActiveTab] = useState('about');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInstitute();
    fetchPosts();
    fetchEvents();
  }, [id]);

  const fetchInstitute = async () => {
    try {
      const response = await instituteAPI.getInstitute(id);
      setInstitute(response.data);
    } catch (error) {
      console.error('Error fetching institute:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPosts = async () => {
    try {
      const response = await postAPI.getPosts({ type: 'institute', instituteId: id });
      setPosts(response.data.posts || []);
    } catch (error) {
      console.error('Error fetching posts:', error);
    }
  };

  const fetchEvents = async () => {
    try {
      const response = await eventAPI.getEvents({ instituteId: id });
      setEvents(response.data.events || []);
    } catch (error) {
      console.error('Error fetching events:', error);
    }
  };

  if (loading) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  if (!institute) {
    return <div className="container mx-auto px-4 py-8">Institute not found</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-start space-x-6">
            {institute.logoUrl && (
              <img
                src={institute.logoUrl}
                alt={institute.name}
                className="w-24 h-24 object-contain"
              />
            )}
            <div className="flex-1">
              <div className="flex items-center space-x-2 mb-2">
                <h1 className="text-3xl font-bold">{institute.name}</h1>
                {institute.verified && (
                  <FiCheckCircle className="text-blue-600" size={24} title="Verified" />
                )}
              </div>
              {institute.alias && (
                <p className="text-gray-600 mb-2">{institute.alias}</p>
              )}
              {institute.description && (
                <p className="text-gray-700 mb-4">{institute.description}</p>
              )}
              <div className="flex flex-wrap gap-4 text-gray-600">
                {institute.location && (
                  <div className="flex items-center space-x-2">
                    <FiMapPin />
                    <span>
                      {institute.location.city}, {institute.location.state}, {institute.location.country}
                    </span>
                  </div>
                )}
                {institute.website && (
                  <a
                    href={institute.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center space-x-2 text-blue-600 hover:text-blue-700"
                  >
                    <FiGlobe />
                    <span>Website</span>
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="flex space-x-4 mb-6 border-b">
          <button
            onClick={() => setActiveTab('about')}
            className={`px-4 py-2 ${
              activeTab === 'about'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600'
            }`}
          >
            About
          </button>
          <button
            onClick={() => setActiveTab('posts')}
            className={`px-4 py-2 ${
              activeTab === 'posts'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600'
            }`}
          >
            Posts
          </button>
          <button
            onClick={() => setActiveTab('events')}
            className={`px-4 py-2 ${
              activeTab === 'events'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600'
            }`}
          >
            Events
          </button>
        </div>

        {activeTab === 'about' && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-semibold mb-4">About {institute.name}</h2>
            <p className="text-gray-700">{institute.description || 'No description available.'}</p>
          </div>
        )}

        {activeTab === 'posts' && (
          <div>
            {posts.length === 0 ? (
              <div className="text-center text-gray-500 py-8">No posts yet</div>
            ) : (
              posts.map((post) => (
                <PostCard key={post._id} post={post} onUpdate={fetchPosts} />
              ))
            )}
          </div>
        )}

        {activeTab === 'events' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.length === 0 ? (
              <div className="col-span-full text-center text-gray-500 py-8">
                No events yet
              </div>
            ) : (
              events.map((event) => (
                <EventCard key={event._id} event={event} onUpdate={fetchEvents} />
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default InstituteDetail;
