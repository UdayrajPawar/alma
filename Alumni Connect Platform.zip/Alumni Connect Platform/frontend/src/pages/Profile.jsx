import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { userAPI, postAPI } from '../services/api';
import PostCard from '../components/PostCard';
import { FiEdit2, FiUserPlus, FiCheck } from 'react-icons/fi';

const Profile = () => {
  const { id } = useParams();
  const { user: currentUser } = useAuth();
  const [profile, setProfile] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [connectionStatus, setConnectionStatus] = useState(null);

  useEffect(() => {
    fetchProfile();
    fetchPosts();
  }, [id]);

  const fetchProfile = async () => {
    try {
      const response = await userAPI.getProfile(id);
      setProfile(response.data);
      
      if (currentUser) {
        const isConnected = response.data.connections?.some(
          (c) => c._id === currentUser.id
        );
        const hasPendingRequest = response.data.receivedConnections?.some(
          (c) => c.userId?._id === currentUser.id
        );
        
        if (isConnected) {
          setConnectionStatus('connected');
        } else if (hasPendingRequest) {
          setConnectionStatus('pending');
        } else {
          setConnectionStatus('none');
        }
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPosts = async () => {
    try {
      const response = await postAPI.getPosts({ type: 'user', userId: id });
      setPosts(response.data.posts);
    } catch (error) {
      console.error('Error fetching posts:', error);
    }
  };

  const handleConnect = async () => {
    try {
      await userAPI.sendConnectionRequest(id);
      setConnectionStatus('pending');
    } catch (error) {
      console.error('Error sending connection request:', error);
    }
  };

  if (loading) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  if (!profile) {
    return <div className="container mx-auto px-4 py-8">Profile not found</div>;
  }

  const isOwnProfile = currentUser?.id === id;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-6">
              {profile.avatarUrl ? (
                <img
                  src={profile.avatarUrl}
                  alt={profile.fullName}
                  className="w-24 h-24 rounded-full"
                />
              ) : (
                <div className="w-24 h-24 rounded-full bg-blue-500 flex items-center justify-center text-white text-3xl">
                  {profile.firstName?.[0]}
                </div>
              )}
              <div>
                <h1 className="text-3xl font-bold">{profile.fullName}</h1>
                {profile.headline && (
                  <p className="text-gray-600 mt-1">{profile.headline}</p>
                )}
                {profile.bio && <p className="text-gray-700 mt-2">{profile.bio}</p>}
                {profile.currentCompany && (
                  <p className="text-gray-600 mt-1">
                    {profile.currentPosition} at {profile.currentCompany}
                  </p>
                )}
                {profile.batch && (
                  <p className="text-gray-600 mt-1">Batch of {profile.batch}</p>
                )}
              </div>
            </div>
            <div className="flex space-x-2">
              {isOwnProfile ? (
                <Link
                  to={`/profile/${id}/edit`}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2"
                >
                  <FiEdit2 />
                  <span>Edit Profile</span>
                </Link>
              ) : (
                connectionStatus === 'none' && (
                  <button
                    onClick={handleConnect}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2"
                  >
                    <FiUserPlus />
                    <span>Connect</span>
                  </button>
                )
              )}
              {connectionStatus === 'pending' && (
                <button
                  disabled
                  className="px-4 py-2 bg-gray-400 text-white rounded-lg flex items-center space-x-2"
                >
                  <FiCheck />
                  <span>Request Sent</span>
                </button>
              )}
            </div>
          </div>

          {profile.skills && profile.skills.length > 0 && (
            <div className="mt-6">
              <h3 className="font-semibold mb-2">Skills</h3>
              <div className="flex flex-wrap gap-2">
                {profile.skills.map((skill, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-4">Posts</h2>
          {posts.length === 0 ? (
            <div className="text-center text-gray-500 py-8">No posts yet</div>
          ) : (
            posts.map((post) => (
              <PostCard key={post._id} post={post} onUpdate={fetchPosts} />
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;

