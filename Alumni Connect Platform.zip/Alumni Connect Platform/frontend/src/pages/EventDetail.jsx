import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { eventAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { FiCalendar, FiMapPin, FiUsers, FiCheck } from 'react-icons/fi';
import { format } from 'date-fns';

const EventDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAttending, setIsAttending] = useState(false);

  useEffect(() => {
    fetchEvent();
  }, [id]);

  const fetchEvent = async () => {
    try {
      const response = await eventAPI.getEvent(id);
      setEvent(response.data);
      setIsAttending(response.data.attendees?.some(a => a._id === user?.id));
    } catch (error) {
      console.error('Error fetching event:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRSVP = async () => {
    try {
      await eventAPI.rsvpEvent(id);
      setIsAttending(!isAttending);
      fetchEvent();
    } catch (error) {
      console.error('Error RSVP:', error);
    }
  };

  if (loading) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  if (!event) {
    return <div className="container mx-auto px-4 py-8">Event not found</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {event.imageUrl && (
            <img
              src={event.imageUrl}
              alt={event.title}
              className="w-full h-64 object-cover"
            />
          )}

          <div className="p-6">
            <div className="flex items-start justify-between mb-4">
              <h1 className="text-3xl font-bold">{event.title}</h1>
              {!isAttending ? (
                <button
                  onClick={handleRSVP}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  RSVP
                </button>
              ) : (
                <button
                  onClick={handleRSVP}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center space-x-2"
                >
                  <FiCheck />
                  <span>Attending</span>
                </button>
              )}
            </div>

            <div className="space-y-4 mb-6">
              <div className="flex items-center space-x-3 text-gray-700">
                <FiCalendar className="text-blue-600" />
                <div>
                  <p className="font-medium">
                    {format(new Date(event.startAt), 'EEEE, MMMM d, yyyy')}
                  </p>
                  <p className="text-sm">
                    {format(new Date(event.startAt), 'h:mm a')}
                    {event.endAt && ` - ${format(new Date(event.endAt), 'h:mm a')}`}
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-3 text-gray-700">
                <FiMapPin className="text-blue-600" />
                <span>{event.location}</span>
              </div>

              <div className="flex items-center space-x-3 text-gray-700">
                <FiUsers className="text-blue-600" />
                <span>
                  {event.attendees?.length || 0} attending
                  {event.capacity && ` / ${event.capacity} capacity`}
                </span>
              </div>
            </div>

            {event.description && (
              <div className="mb-6">
                <h2 className="text-xl font-semibold mb-2">About this event</h2>
                <p className="text-gray-700 whitespace-pre-wrap">{event.description}</p>
              </div>
            )}

            {event.hostUserId && (
              <div className="border-t pt-6">
                <h2 className="text-xl font-semibold mb-4">Hosted by</h2>
                <Link
                  to={`/profile/${event.hostUserId._id}`}
                  className="flex items-center space-x-3 hover:bg-gray-50 p-2 rounded-lg"
                >
                  {event.hostUserId.avatarUrl ? (
                    <img
                      src={event.hostUserId.avatarUrl}
                      alt={event.hostUserId.fullName}
                      className="w-12 h-12 rounded-full"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white">
                      {event.hostUserId.firstName?.[0]}
                    </div>
                  )}
                  <div>
                    <p className="font-medium">{event.hostUserId.fullName}</p>
                    {event.hostUserId.headline && (
                      <p className="text-sm text-gray-600">{event.hostUserId.headline}</p>
                    )}
                  </div>
                </Link>
              </div>
            )}

            {event.attendees && event.attendees.length > 0 && (
              <div className="border-t pt-6 mt-6">
                <h2 className="text-xl font-semibold mb-4">Attendees</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {event.attendees.slice(0, 12).map((attendee) => (
                    <Link
                      key={attendee._id}
                      to={`/profile/${attendee._id}`}
                      className="flex items-center space-x-2 hover:bg-gray-50 p-2 rounded-lg"
                    >
                      {attendee.avatarUrl ? (
                        <img
                          src={attendee.avatarUrl}
                          alt={attendee.fullName}
                          className="w-10 h-10 rounded-full"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white text-sm">
                          {attendee.firstName?.[0]}
                        </div>
                      )}
                      <span className="text-sm truncate">{attendee.fullName}</span>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventDetail;
