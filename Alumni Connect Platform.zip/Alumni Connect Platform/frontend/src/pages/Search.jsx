import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { userAPI, instituteAPI, jobAPI, eventAPI } from '../services/api';

const Search = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [activeTab, setActiveTab] = useState('users');
  const [results, setResults] = useState({
    users: [],
    institutes: [],
    jobs: [],
    events: [],
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (query) {
      performSearch();
    }
  }, [query, activeTab]);

  const performSearch = async () => {
    setLoading(true);
    try {
      if (activeTab === 'users') {
        const response = await userAPI.searchUsers({ q: query });
        setResults({ ...results, users: response.data.users });
      } else if (activeTab === 'institutes') {
        const response = await instituteAPI.getInstitutes({ q: query });
        setResults({ ...results, institutes: response.data.institutes });
      } else if (activeTab === 'jobs') {
        const response = await jobAPI.getJobs({ q: query });
        setResults({ ...results, jobs: response.data.jobs });
      } else if (activeTab === 'events') {
        const response = await eventAPI.getEvents({ q: query });
        setResults({ ...results, events: response.data.events });
      }
    } catch (error) {
      console.error('Error searching:', error);
    } finally {
      setLoading(false);
    }
  };

  const tabs = ['users', 'institutes', 'jobs', 'events'];

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Search Results for "{query}"</h1>

      <div className="flex space-x-4 mb-6 border-b">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 capitalize ${
              activeTab === tab
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-8">Loading...</div>
      ) : (
        <div>
          {activeTab === 'users' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {results.users.map((user) => (
                <Link
                  key={user._id}
                  to={`/profile/${user._id}`}
                  className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center space-x-3">
                    {user.avatarUrl ? (
                      <img
                        src={user.avatarUrl}
                        alt={user.fullName}
                        className="w-12 h-12 rounded-full"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white">
                        {user.firstName?.[0]}
                      </div>
                    )}
                    <div>
                      <h3 className="font-semibold">{user.fullName}</h3>
                      {user.headline && (
                        <p className="text-sm text-gray-600">{user.headline}</p>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          {activeTab === 'institutes' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {results.institutes.map((institute) => (
                <Link
                  key={institute._id}
                  to={`/institutes/${institute._id}`}
                  className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
                >
                  {institute.logoUrl && (
                    <img
                      src={institute.logoUrl}
                      alt={institute.name}
                      className="w-16 h-16 mb-2"
                    />
                  )}
                  <h3 className="font-semibold">{institute.name}</h3>
                  {institute.description && (
                    <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                      {institute.description}
                    </p>
                  )}
                </Link>
              ))}
            </div>
          )}

          {activeTab === 'jobs' && (
            <div>
              {results.jobs.map((job) => (
                <div
                  key={job._id}
                  className="bg-white rounded-lg shadow-md p-6 mb-4 hover:shadow-lg transition-shadow"
                >
                  <Link to={`/jobs/${job._id}`}>
                    <h3 className="text-xl font-semibold mb-2 hover:text-blue-600">
                      {job.title}
                    </h3>
                  </Link>
                  <p className="text-gray-600">{job.company}</p>
                  {job.location && <p className="text-gray-600">{job.location}</p>}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'events' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {results.events.map((event) => (
                <Link
                  key={event._id}
                  to={`/events/${event._id}`}
                  className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
                >
                  {event.imageUrl && (
                    <img
                      src={event.imageUrl}
                      alt={event.title}
                      className="w-full h-32 object-cover"
                    />
                  )}
                  <div className="p-4">
                    <h3 className="font-semibold">{event.title}</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      {new Date(event.startAt).toLocaleDateString()}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Search;

