import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { postAPI } from '../services/api';
import PostCard from '../components/PostCard';
import { FiPlus } from 'react-icons/fi';

const Home = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [newPost, setNewPost] = useState({ content: '', media: [] });

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await postAPI.getPosts({ type: 'feed' });
      setPosts(response.data.posts);
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePost = async (e) => {
    e.preventDefault();
    try {
      await postAPI.createPost(newPost);
      setNewPost({ content: '', media: [] });
      setShowCreatePost(false);
      fetchPosts();
    } catch (error) {
      console.error('Error creating post:', error);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">Loading...</div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        {user && (
          <div className="bg-white rounded-lg shadow-md p-4 mb-6">
            <button
              onClick={() => setShowCreatePost(!showCreatePost)}
              className="w-full text-left text-gray-500 hover:text-gray-700"
            >
              <div className="flex items-center space-x-3">
                {user.avatarUrl ? (
                  <img
                    src={user.avatarUrl}
                    alt={user.firstName}
                    className="w-10 h-10 rounded-full"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white">
                    {user.firstName?.[0]}
                  </div>
                )}
                <span>What's on your mind?</span>
              </div>
            </button>

            {showCreatePost && (
              <form onSubmit={handleCreatePost} className="mt-4">
                <textarea
                  value={newPost.content}
                  onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                  placeholder="Share an update..."
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 mb-3"
                  rows="4"
                />
                <div className="flex items-center justify-between">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={(e) =>
                      setNewPost({ ...newPost, media: Array.from(e.target.files) })
                    }
                    className="text-sm"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2"
                  >
                    <FiPlus />
                    <span>Post</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        <div>
          {posts.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              No posts yet. Be the first to share something!
            </div>
          ) : (
            posts.map((post) => (
              <PostCard key={post._id} post={post} onUpdate={fetchPosts} />
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;

