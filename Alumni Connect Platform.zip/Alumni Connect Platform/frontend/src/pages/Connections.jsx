import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { userAPI } from '../services/api';
import { FiCheck, FiX, FiUserPlus } from 'react-icons/fi';

const Connections = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('connections');
  const [connections, setConnections] = useState([]);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [connectionsRes, requestsRes] = await Promise.all([
        userAPI.getConnections(user.id),
        userAPI.getConnectionRequests()
      ]);
      setConnections(connectionsRes.data.connections || []);
      setRequests(requestsRes.data.requests || []);
    } catch (error) {
      console.error('Error fetching connections:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (userId) => {
    try {
      await userAPI.acceptConnection(userId);
      fetchData();
    } catch (error) {
      console.error('Error accepting connection:', error);
    }
  };

  const handleReject = async (userId) => {
    try {
      await userAPI.removeConnection(userId);
      fetchData();
    } catch (error) {
      console.error('Error rejecting connection:', error);
    }
  };

  if (loading) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">My Network</h1>

        <div className="flex space-x-4 mb-6 border-b">
          <button
            onClick={() => setActiveTab('connections')}
            className={`px-4 py-2 ${
              activeTab === 'connections'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600'
            }`}
          >
            Connections ({connections.length})
          </button>
          <button
            onClick={() => setActiveTab('requests')}
            className={`px-4 py-2 ${
              activeTab === 'requests'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600'
            }`}
          >
            Requests ({requests.length})
          </button>
        </div>

        {activeTab === 'connections' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {connections.length === 0 ? (
              <div className="col-span-full text-center text-gray-500 py-8">
                No connections yet
              </div>
            ) : (
              connections.map((connection) => (
                <div
                  key={connection._id}
                  className="bg-white rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
                >
                  <Link
                    to={`/profile/${connection._id}`}
                    className="flex items-center space-x-3"
                  >
                    {connection.avatarUrl ? (
                      <img
                        src={connection.avatarUrl}
                        alt={connection.fullName}
                        className="w-16 h-16 rounded-full"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-full bg-blue-500 flex items-center justify-center text-white text-xl">
                        {connection.firstName?.[0]}
                      </div>
                    )}
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg">{connection.fullName}</h3>
                      {connection.headline && (
                        <p className="text-sm text-gray-600">{connection.headline}</p>
                      )}
                      {connection.currentCompany && (
                        <p className="text-sm text-gray-500">{connection.currentCompany}</p>
                      )}
                    </div>
                  </Link>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'requests' && (
          <div className="space-y-4">
            {requests.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                No pending requests
              </div>
            ) : (
              requests.map((request) => (
                <div
                  key={request.userId._id}
                  className="bg-white rounded-lg shadow-md p-4 flex items-center justify-between"
                >
                  <Link
                    to={`/profile/${request.userId._id}`}
                    className="flex items-center space-x-3 flex-1"
                  >
                    {request.userId.avatarUrl ? (
                      <img
                        src={request.userId.avatarUrl}
                        alt={request.userId.fullName}
                        className="w-16 h-16 rounded-full"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded-full bg-blue-500 flex items-center justify-center text-white text-xl">
                        {request.userId.firstName?.[0]}
                      </div>
                    )}
                    <div>
                      <h3 className="font-semibold text-lg">{request.userId.fullName}</h3>
                      {request.userId.headline && (
                        <p className="text-sm text-gray-600">{request.userId.headline}</p>
                      )}
                    </div>
                  </Link>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleAccept(request.userId._id)}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center space-x-2"
                    >
                      <FiCheck />
                      <span>Accept</span>
                    </button>
                    <button
                      onClick={() => handleReject(request.userId._id)}
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 flex items-center space-x-2"
                    >
                      <FiX />
                      <span>Decline</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Connections;
