import axios from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refreshToken = localStorage.getItem('refreshToken');
        const response = await axios.post(`${API_URL}/auth/refresh`, {
          refreshToken,
        });

        const { accessToken, refreshToken: newRefreshToken } = response.data;
        localStorage.setItem('accessToken', accessToken);
        localStorage.setItem('refreshToken', newRefreshToken);

        originalRequest.headers.Authorization = `Bearer ${accessToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  forgotPassword: (email) => api.post('/auth/forgot-password', { email }),
  resetPassword: (data) => api.post('/auth/reset-password', data),
};

export const userAPI = {
  getProfile: (id) => api.get(`/users/${id}`),
  updateProfile: (id, data) => api.put(`/users/${id}`, data),
  searchUsers: (params) => api.get('/users/search', { params }),
  sendConnectionRequest: (id) => api.post(`/users/${id}/connect`),
  acceptConnection: (id) => api.post(`/users/${id}/connect/accept`),
  removeConnection: (id) => api.delete(`/users/${id}/connect`),
  getConnections: (id) => api.get(`/users/${id}/connections`),
  getConnectionRequests: () => api.get('/users/connections/requests'),
};

export const postAPI = {
  createPost: (data) => {
    const formData = new FormData();
    formData.append('content', data.content);
    if (data.tags) formData.append('tags', data.tags);
    if (data.instituteId) formData.append('instituteId', data.instituteId);
    if (data.media) {
      data.media.forEach((file) => formData.append('media', file));
    }
    return api.post('/posts', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  getPosts: (params) => api.get('/posts', { params }),
  getPost: (id) => api.get(`/posts/${id}`),
  likePost: (id) => api.post(`/posts/${id}/like`),
  addComment: (id, data) => api.post(`/posts/${id}/comment`, data),
  getComments: (id) => api.get(`/posts/${id}/comments`),
  deletePost: (id) => api.delete(`/posts/${id}`),
};

export const eventAPI = {
  createEvent: (data) => {
    const formData = new FormData();
    Object.keys(data).forEach((key) => {
      if (key === 'image' && data[key]) {
        formData.append('image', data[key]);
      } else if (data[key] !== null && data[key] !== undefined) {
        formData.append(key, data[key]);
      }
    });
    return api.post('/events', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  getEvents: (params) => api.get('/events', { params }),
  getEvent: (id) => api.get(`/events/${id}`),
  rsvpEvent: (id) => api.post(`/events/${id}/rsvp`),
  deleteEvent: (id) => api.delete(`/events/${id}`),
};

export const jobAPI = {
  createJob: (data) => api.post('/jobs', data),
  getJobs: (params) => api.get('/jobs', { params }),
  getJob: (id) => api.get(`/jobs/${id}`),
  applyJob: (id, resume) => {
    const formData = new FormData();
    if (resume) formData.append('resume', resume);
    return api.post(`/jobs/${id}/apply`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  deleteJob: (id) => api.delete(`/jobs/${id}`),
};

export const messageAPI = {
  getConversations: () => api.get('/messages'),
  getOrCreateConversation: (data) => api.post('/messages', data),
  getMessages: (id, params) => api.get(`/messages/${id}/messages`, { params }),
  sendMessage: (id, data) => {
    const formData = new FormData();
    formData.append('content', data.content || '');
    if (data.attachments) {
      data.attachments.forEach((file) => formData.append('attachments', file));
    }
    return api.post(`/messages/${id}/messages`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  markAsRead: (id) => api.post(`/messages/${id}/read`),
};

export const notificationAPI = {
  getNotifications: (params) => api.get('/notifications', { params }),
  markAsRead: (id) => api.post(`/notifications/${id}/read`),
  markAllAsRead: () => api.post('/notifications/read-all'),
};

export const instituteAPI = {
  createInstitute: (data) => {
    const formData = new FormData();
    Object.keys(data).forEach((key) => {
      if (key === 'logo' && data[key]) {
        formData.append('logo', data[key]);
      } else if (data[key] !== null && data[key] !== undefined) {
        formData.append(key, data[key]);
      }
    });
    return api.post('/institutes', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  getInstitutes: (params) => api.get('/institutes', { params }),
  getInstitute: (id) => api.get(`/institutes/${id}`),
  updateInstitute: (id, data) => {
    const formData = new FormData();
    Object.keys(data).forEach((key) => {
      if (key === 'logo' && data[key]) {
        formData.append('logo', data[key]);
      } else if (data[key] !== null && data[key] !== undefined) {
        formData.append(key, data[key]);
      }
    });
    return api.put(`/institutes/${id}`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

export default api;

