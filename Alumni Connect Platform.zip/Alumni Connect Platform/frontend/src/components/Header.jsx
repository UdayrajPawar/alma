import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { FiSearch, FiMessageCircle, FiUsers, FiLogOut } from 'react-icons/fi';
import NotificationBell from './NotificationBell';

const Header = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link to="/" className="text-2xl font-bold text-blue-600">
            Alumni Connect
          </Link>

          {user && (
            <>
              <form onSubmit={handleSearch} className="flex-1 max-w-xl mx-4">
                <div className="relative">
                  <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search alumni, institutes, jobs..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </form>

              <div className="hidden md:flex items-center space-x-1 mr-4">
                <Link
                  to="/"
                  className="px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg text-sm"
                >
                  Home
                </Link>
                <Link
                  to="/events"
                  className="px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg text-sm"
                >
                  Events
                </Link>
                <Link
                  to="/jobs"
                  className="px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg text-sm"
                >
                  Jobs
                </Link>
                {(user.roles?.includes('platform_admin') || user.roles?.includes('institute_admin')) && (
                  <Link
                    to="/admin"
                    className="px-3 py-2 text-gray-700 hover:bg-gray-100 rounded-lg text-sm"
                  >
                    Admin
                  </Link>
                )}
              </div>

              <nav className="flex items-center space-x-2">
                <Link
                  to="/connections"
                  className="p-2 hover:bg-gray-100 rounded-full relative"
                  title="Connections"
                >
                  <FiUsers size={24} className="text-gray-600" />
                </Link>
                <Link
                  to="/messages"
                  className="p-2 hover:bg-gray-100 rounded-full relative"
                  title="Messages"
                >
                  <FiMessageCircle size={24} className="text-gray-600" />
                </Link>
                <NotificationBell />
                <Link
                  to={`/profile/${user.id}`}
                  className="flex items-center space-x-2 hover:bg-gray-100 px-3 py-2 rounded-lg"
                >
                  {user.avatarUrl ? (
                    <img
                      src={user.avatarUrl}
                      alt={user.firstName}
                      className="w-8 h-8 rounded-full"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-white">
                      {user.firstName?.[0]}
                    </div>
                  )}
                  <span className="text-sm font-medium">{user.firstName}</span>
                </Link>
                <button
                  onClick={handleLogout}
                  className="p-2 hover:bg-gray-100 rounded-full"
                  title="Logout"
                >
                  <FiLogOut size={24} className="text-gray-600" />
                </button>
              </nav>
            </>
          )}

          {!user && (
            <div className="flex items-center space-x-4">
              <Link
                to="/login"
                className="px-4 py-2 text-gray-700 hover:text-blue-600"
              >
                Login
              </Link>
              <Link
                to="/register"
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;

