import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { FiBriefcase, FiMapPin, FiClock } from 'react-icons/fi';

const JobCard = ({ job }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-4 hover:shadow-lg transition-shadow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <Link to={`/jobs/${job._id}`}>
            <h3 className="text-xl font-semibold mb-2 hover:text-blue-600">
              {job.title}
            </h3>
          </Link>
          <div className="flex items-center text-gray-600 mb-2">
            <FiBriefcase className="mr-2" />
            <span>{job.company}</span>
          </div>
          {job.location && (
            <div className="flex items-center text-gray-600 mb-2">
              <FiMapPin className="mr-2" />
              <span>{job.location}</span>
            </div>
          )}
          {job.type && (
            <span className="inline-block px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm mr-2">
              {job.type}
            </span>
          )}
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-500">
            <FiClock className="inline mr-1" />
            {formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}
          </p>
        </div>
      </div>
      {job.description && (
        <p className="text-gray-600 mb-4 line-clamp-2">{job.description}</p>
      )}
      <Link
        to={`/jobs/${job._id}`}
        className="text-blue-600 hover:text-blue-700 font-medium"
      >
        View Details →
      </Link>
    </div>
  );
};

export default JobCard;

