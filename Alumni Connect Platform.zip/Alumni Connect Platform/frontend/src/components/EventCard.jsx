import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { FiCalendar, FiMapPin, FiUsers } from 'react-icons/fi';
import { eventAPI } from '../services/api';

const EventCard = ({ event, onUpdate }) => {
  const [attending, setAttending] = useState(
    event.attendees?.some((a) => a._id === event.attendees?.[0]?._id) || false
  );
  const [attendeesCount, setAttendeesCount] = useState(event.attendees?.length || 0);
  const [loading, setLoading] = useState(false);

  const handleRSVP = async () => {
    if (loading) return;
    setLoading(true);
    try {
      const response = await eventAPI.rsvpEvent(event._id);
      setAttending(response.data.attending);
      setAttendeesCount(response.data.attendeesCount);
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error('Error RSVPing to event:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      {event.imageUrl && (
        <img
          src={event.imageUrl}
          alt={event.title}
          className="w-full h-48 object-cover"
        />
      )}
      <div className="p-6">
        <Link to={`/events/${event._id}`}>
          <h3 className="text-xl font-semibold mb-2 hover:text-blue-600">
            {event.title}
          </h3>
        </Link>
        {event.description && (
          <p className="text-gray-600 mb-4 line-clamp-2">{event.description}</p>
        )}
        <div className="space-y-2 mb-4">
          <div className="flex items-center text-gray-600">
            <FiCalendar className="mr-2" />
            <span>{format(new Date(event.startAt), 'PPp')}</span>
          </div>
          {event.location && (
            <div className="flex items-center text-gray-600">
              <FiMapPin className="mr-2" />
              <span>{event.location}</span>
            </div>
          )}
          <div className="flex items-center text-gray-600">
            <FiUsers className="mr-2" />
            <span>
              {attendeesCount} {event.capacity ? `/ ${event.capacity}` : ''} attendees
            </span>
          </div>
        </div>
        <button
          onClick={handleRSVP}
          disabled={loading}
          className={`w-full py-2 rounded-lg font-medium ${
            attending
              ? 'bg-green-500 text-white hover:bg-green-600'
              : 'bg-blue-600 text-white hover:bg-blue-700'
          }`}
        >
          {loading ? 'Loading...' : attending ? 'Attending' : 'RSVP'}
        </button>
      </div>
    </div>
  );
};

export default EventCard;

