import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { FiHeart, FiMessageCircle, FiShare2, FiTrash2 } from 'react-icons/fi';
import { postAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

const PostCard = ({ post, onUpdate }) => {
  const { user } = useAuth();
  const [liked, setLiked] = useState(post.likes?.includes(user?.id) || false);
  const [likesCount, setLikesCount] = useState(post.likes?.length || 0);
  const [loading, setLoading] = useState(false);

  const handleLike = async () => {
    if (loading) return;
    setLoading(true);
    try {
      const response = await postAPI.likePost(post._id);
      setLiked(response.data.liked);
      setLikesCount(response.data.likesCount);
    } catch (error) {
      console.error('Error liking post:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this post?')) return;
    try {
      await postAPI.deletePost(post._id);
      if (onUpdate) onUpdate();
    } catch (error) {
      console.error('Error deleting post:', error);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-4">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Link to={`/profile/${post.author?._id || post.author}`}>
            {post.author?.avatarUrl ? (
              <img
                src={post.author.avatarUrl}
                alt={post.author.firstName}
                className="w-12 h-12 rounded-full"
              />
            ) : (
              <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center text-white">
                {post.author?.firstName?.[0] || 'U'}
              </div>
            )}
          </Link>
          <div>
            <Link
              to={`/profile/${post.author?._id || post.author}`}
              className="font-semibold hover:text-blue-600"
            >
              {post.author?.firstName} {post.author?.lastName}
            </Link>
            {post.author?.headline && (
              <p className="text-sm text-gray-500">{post.author.headline}</p>
            )}
            <p className="text-xs text-gray-400">
              {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
            </p>
          </div>
        </div>
        {user?.id === (post.author?._id || post.author) && (
          <button
            onClick={handleDelete}
            className="text-red-500 hover:text-red-700"
          >
            <FiTrash2 />
          </button>
        )}
      </div>

      {post.content && (
        <p className="mb-4 text-gray-800 whitespace-pre-wrap">{post.content}</p>
      )}

      {post.mediaUrls && post.mediaUrls.length > 0 && (
        <div className="mb-4 grid grid-cols-2 gap-2">
          {post.mediaUrls.map((url, index) => (
            <img
              key={index}
              src={url}
              alt={`Post media ${index + 1}`}
              className="w-full h-48 object-cover rounded-lg"
            />
          ))}
        </div>
      )}

      {post.tags && post.tags.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-4">
          {post.tags.map((tag, index) => (
            <span
              key={index}
              className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-sm"
            >
              #{tag}
            </span>
          ))}
        </div>
      )}

      <div className="flex items-center space-x-6 pt-4 border-t">
        <button
          onClick={handleLike}
          className={`flex items-center space-x-2 ${
            liked ? 'text-red-500' : 'text-gray-600'
          } hover:text-red-500`}
        >
          <FiHeart className={liked ? 'fill-current' : ''} />
          <span>{likesCount}</span>
        </button>
        <Link
          to={`/posts/${post._id}`}
          className="flex items-center space-x-2 text-gray-600 hover:text-blue-600"
        >
          <FiMessageCircle />
          <span>{post.commentsCount || 0}</span>
        </Link>
        <button className="flex items-center space-x-2 text-gray-600 hover:text-blue-600">
          <FiShare2 />
          <span>Share</span>
        </button>
      </div>
    </div>
  );
};

export default PostCard;

