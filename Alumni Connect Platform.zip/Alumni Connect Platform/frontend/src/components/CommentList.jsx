import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';

const CommentList = ({ comments }) => {
  if (!comments || comments.length === 0) {
    return (
      <div className="text-center text-gray-500 py-4">
        No comments yet. Be the first to comment!
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {comments.map((comment) => (
        <div key={comment._id} className="flex space-x-3">
          <Link to={`/profile/${comment.author._id}`}>
            {comment.author.avatarUrl ? (
              <img
                src={comment.author.avatarUrl}
                alt={comment.author.fullName}
                className="w-10 h-10 rounded-full"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white">
                {comment.author.firstName?.[0]}
              </div>
            )}
          </Link>
          <div className="flex-1">
            <div className="bg-gray-100 rounded-lg p-3">
              <Link
                to={`/profile/${comment.author._id}`}
                className="font-semibold hover:text-blue-600"
              >
                {comment.author.fullName}
              </Link>
              <p className="text-gray-800 mt-1">{comment.content}</p>
            </div>
            <p className="text-xs text-gray-500 mt-1 ml-3">
              {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default CommentList;
