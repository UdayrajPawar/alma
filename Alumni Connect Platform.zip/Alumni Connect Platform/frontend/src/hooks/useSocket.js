import { useEffect, useRef } from 'react';
import io from 'socket.io-client';

const SOCKET_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000';

export const useSocket = (token, callbacks = {}) => {
  const socketRef = useRef(null);

  useEffect(() => {
    if (!token) return;

    socketRef.current = io(SOCKET_URL, {
      auth: { token },
      transports: ['websocket'],
    });

    const socket = socketRef.current;

    socket.on('connect', () => {
      console.log('Socket connected');
      if (callbacks.onConnect) callbacks.onConnect();
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected');
      if (callbacks.onDisconnect) callbacks.onDisconnect();
    });

    socket.on('new-message', (message) => {
      if (callbacks.onNewMessage) callbacks.onNewMessage(message);
    });

    socket.on('new-notification', (notification) => {
      if (callbacks.onNewNotification) callbacks.onNewNotification(notification);
    });

    socket.on('message-sent', (message) => {
      if (callbacks.onMessageSent) callbacks.onMessageSent(message);
    });

    socket.on('user-typing', (data) => {
      if (callbacks.onUserTyping) callbacks.onUserTyping(data);
    });

    socket.on('user-stop-typing', (data) => {
      if (callbacks.onUserStopTyping) callbacks.onUserStopTyping(data);
    });

    socket.on('error', (error) => {
      console.error('Socket error:', error);
      if (callbacks.onError) callbacks.onError(error);
    });

    return () => {
      socket.disconnect();
    };
  }, [token]);

  const joinConversation = (conversationId) => {
    if (socketRef.current) {
      socketRef.current.emit('join-conversation', conversationId);
    }
  };

  const leaveConversation = (conversationId) => {
    if (socketRef.current) {
      socketRef.current.emit('leave-conversation', conversationId);
    }
  };

  const sendMessage = (data) => {
    if (socketRef.current) {
      socketRef.current.emit('send-message', data);
    }
  };

  const typing = (conversationId) => {
    if (socketRef.current) {
      socketRef.current.emit('typing', { conversationId });
    }
  };

  const stopTyping = (conversationId) => {
    if (socketRef.current) {
      socketRef.current.emit('stop-typing', { conversationId });
    }
  };

  return {
    socket: socketRef.current,
    joinConversation,
    leaveConversation,
    sendMessage,
    typing,
    stopTyping,
  };
};

